
ddE_PtM = zeros(6,1);   % Column vector like x = [0; 1; 2]
T = 600;                % K
[dG,dGa] = Fcn_GCalculation(ddE_PtM, T); 
dG(end) = dG(end) + 0.5;    % dG(end) is TOL adsorption energy, co-ads effect
PMCH = 10^5;
PTOL = 0;
PH2 = 0;
vin = 0.1*10^(-6);       %m^3/s
[TOF_sim, SCfin, SCH, kall] = RateSimulator_org(dG,dGa,T,vin,PMCH,PTOL,PH2);

