clear 

load('TrainedC7HXMLModels.mat');
Etolgas = -1222.32;
EH2gas = -31.704468;

for k = 1:6
    sd0{k} = SingleData;
    sd0{k}.Egas = Etolgas+(14-k-8)/2*EH2gas;
    [sd0{k}, Astr{k}, Adata{k}] = ReadXYZ(sd0{k}, ['RefXYZFiles/ref_C7H' num2str(14-k) '.xyz'], 'RefXYZFiles/ref_PtNC.xyz');
    if(k==6)
        ytete=1;
    end
    [sd0{k}, indexAS{k}, index_allASNN{k}] = AS1NNinfo(sd0{k}, Astr{k}, Adata{k});
    tempASandNN = [indexAS{k} index_allASNN{k}];
    tempASandNN = unique(tempASandNN);
    index_ASandNN{k} = tempASandNN;
end

AP = importdata('AtomProperties.xlsx');
for i = 1:length(AP.textdata)
    AtomStr{i} = AP.textdata{i};
    AtomColor(i,1:3)= AP.data(i,4:6);
end

usedM = [1,4,7,10,14,16,18,19,20,21];
indexASTOL = indexAS{6};
indexNNTOL = index_allASNN{6};
ti = 1;
for i = 1:length(indexASTOL)
    for j = i:length(indexASTOL)
        for k = 1:3:length(indexNNTOL)
            index_Mdopedall{ti} = [indexASTOL(i:j) randsample(indexNNTOL,k)];
            ti = ti+1;
        end
    end
end

dEads_TOL = zeros(length(usedM),length(index_Mdopedall));
dEprediction = cell(length(usedM),length(index_Mdopedall));
for ai = 1:length(usedM)
    for Mi = 1:length(index_Mdopedall)
        if(ai<2 && Mi>1)
            TOFsim(1,Mi) = TOFsim(1,1);
            SCfin{1,Mi} = SCfin{1,1};
            kall{1,Mi} = kall{1,1};
            continue;
        end
        M = AtomStr{usedM(ai)};
        index_Mdoped = index_Mdopedall{Mi};
        ddE_PtM = zeros(6,1);
        for k = 1:6
            Astr_M = Astr{k};
            for i = 1:length(index_Mdoped)
                Astr_M{index_Mdoped(i)}=M;
            end
            sd_M{k} = SingleData;
            [sd_M{k}, indexAS_M{k}, index_allASNN_M{k}] = AS1NNinfo(sd_M{k}, Astr_M, Adata{k});
            sd_M{k}.dCM=[];
            sd_M{k} = FingerPrinting(sd_M{k});
            sd_M{k} = Prediction(sd_M{k}, C7HX{k}.MLmodel);
            if(ai==1)
                sd_M{k}.dE_test = sd0{k}.dE_train;
            end
            ddE_PtM(k) = sd_M{k}.dE_test-sd0{k}.dE_train;  
        end
        
        dEprediction{ai,Mi} = ddE_PtM;

        Tsim = 600;
        PH2 = 0;
        PMCH = 10^5;
        PTOL = 0;
        vin =  1*10^(-6); 
        [dG,dGact]= Fcn_GCalculation(ddE_PtM, Tsim);
        dG(end) = dG(end) + 0.5;
        [TOFsim(ai,Mi), SCfin{ai,Mi}, SCH(ai,Mi), kall{ai,Mi}] = RateSimulator_org(dG,dGact,Tsim,vin,PMCH,PTOL,PH2);
        
        if(TOFsim(ai,Mi)<0)
            disp('Negative TOF:');
            disp(M);
            disp(index_Mdoped);
        end
        
        dEads_TOL(ai,Mi) = sd_M{k}.dE_test-sd0{k}.dE_train;
    end
end

save('Data_CatalystScreening.mat');

