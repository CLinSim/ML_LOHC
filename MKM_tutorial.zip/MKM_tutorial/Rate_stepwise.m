function [TOF_sim, SCfin, SCH, kall] = Rate_stepwise(dG,dGa,T,PMCH,PTOL,PH2)

kB = 1.38064*10^(-23);
RT = 8.3145*T/96485;
h = 6.62607015*10^(-34);
area_AS = 1*10^(-19);  %m^2
atomMass = 1.6605*10^(-24);

vout = vin;
NA = 6.02*10^23;
V = 1*10^(-6);         % m^3
V_cat = 0.1*10^(-6);      % m^3
area_cat = 0.2*10^6;          % m^2/kg
density_cat = 0.15*10^3;        % kg/m^3
porosity = 0.6;
MassRI = zeros(1,7); 
MassRI(1) = 98;
MassRI(end) = 92;

density_AS = area_cat*density_cat*(1-porosity)/(NA*area_AS);    %mol/m^3
mol_AS = density_AS*V_cat;      %mol;

tend = 4000.0;
dt0 = 1*10^(-3);
wt = 1.001;
dt = dt0;
tlist = zeros(1);
while(tlist(end)<tend)
    tlist = [tlist tlist(end)+dt]; 
    dt = dt*wt;
end
tlist(end) = tend;
nT = length(tlist);
y0 = zeros(7,nT); 

for k = 2:nT
    dT = tlist(k)-tlist(k-1);

    KeqH2 = exp(-dG(7)/RT)*PH2/100000;
    Hads = sqrt(KeqH2)/(1+sqrt(KeqH2));
    starads = 1-Hads;

    CoeffMatrix_itoj = zeros(9,9);
    bCoeff = zeros(9,1);
    for i = 1:7
        CoeffMatrix_itoj(i,i) = 1/dT;
        if(i<7)
            CoeffMatrix_itoj(i,i) = CoeffMatrix_itoj(i,i) + kB*T/h*exp(-dGa(i)/RT)*starads;
            CoeffMatrix_itoj(i,i+1) = -kB*T/h*exp(-(dGa(i)-dG(i))/RT)*Hads;
        end
        if(i>1)
            CoeffMatrix_itoj(i,i) = CoeffMatrix_itoj(i,i) + kB*T/h*exp(-(dGa(i-1)-dG(i-1))/RT)*Hads;
            CoeffMatrix_itoj(i,i-1) = -kB*T/h*exp(-dGa(i-1)/RT)*starads;
        end
        bCoeff(i) = y0(i,k-1)/dT;
    end
    kads = zeros(1,7);
    kdes = zeros(1,7);
    kads(1) = area_AS/sqrt(2*pi*MassRI(1)*atomMass*kB*T);
    kdes(1) = kads(1)*100000/exp(-dG(8)/RT);
    kads(7) = area_AS/sqrt(2*pi*MassRI(7)*atomMass*kB*T);
    kdes(7) = kads(7)*100000/exp(-dG(9)/RT);

    CoeffMatrix_itoj(1,1) = CoeffMatrix_itoj(1,1) + kdes(1);
    CoeffMatrix_itoj(1,1:7) = CoeffMatrix_itoj(1,1:7) + kads(1)*PMCH;
    bCoeff(1) = bCoeff(1) + kads(1)*PMCH;
    CoeffMatrix_itoj(7,7) = CoeffMatrix_itoj(7,7) + kdes(7);
    CoeffMatrix_itoj(7,1:7) = CoeffMatrix_itoj(7,1:7) + kads(7)*PTOL;
    bCoeff(7) = bCoeff(7) + kads(7)*PTOL;

    tempsolve = CoeffMatrix_itoj\bCoeff;
    y0(:,k) = tempsolve;
end

TOF_sim = kads(1)*PMCH*(1-sum(y0(1:7,end))) - kdes(1)*y0(1,end);
SCfin = y0(:,end);

SCH = Hads;

kall = zeros(8,2);
for i = 1:6
	kall(i,1) = kB*T/h*exp(-dGa(i)/RT);
	kall(i,2)= kB*T/h*exp(-(dGa(i)-dG(i))/RT);
end
kall(7,1) = kads(1);
kall(7,2) = kdes(1);
kall(8,1) = kads(7);
kall(8,2) = kdes(7);

end