classdef EnsembleData

    properties
        dE_trains;
        FingerPrints;
        MLmodel;
        MAE_MLmodel;
        dE_tests;
        MAE_tests;
        uncertaintys;
        BulkElements;
        DopingElements
        DIs;
        ASnos;
        sds;
        

        moleculeName = 'T';
    end


    methods
        function obj = FolderAnalysis(obj, foldername, newEgas)
            listing = dir(foldername);
            if(length(listing(1).name)<3)
                noStructures= round((length(listing)-2)/2);
            else
                noStructures= round((length(listing))/2);
            end

            obj.dE_trains = zeros(noStructures,1);
            obj.BulkElements = strings(noStructures,1);
            obj.DopingElements = strings(noStructures,1);
            obj.FingerPrints= zeros(noStructures,3);
            obj.DIs = zeros(noStructures,1);
            obj.ASnos = zeros(noStructures,1);

            for i = 1:noStructures
                F = sprintf('%d_*.xyz',i);
                S = dir(fullfile(foldername, F));
                for j = 1:length(S)
                    tempName = S(j).name;
                    for k = 1:length(tempName)
                        if(isequal(tempName(k), '_'))
                            letter = tempName(k+1);
                            break
                        end
                    end
                    switch letter
                        case obj.moleculeName
                            filenameAds = [foldername  '/' tempName];
                        otherwise
                            filenameNC = [foldername  '/' tempName];
                    end
                end
                sd = SingleData;
                if(~isempty(newEgas))
                    sd.Egas = newEgas;
                end
                [sd, Astr, Adata] = ReadXYZ(sd, filenameAds, filenameNC);
                sd = AS1NNinfo(sd, Astr, Adata);
                sd = FingerPrinting(sd);

                obj.dE_trains(i) = sd.dE_train;
                obj.FingerPrints(i,1:3) = sd.FingerPrint;
                obj.BulkElements(i) = sd.BulkElement;
                if(~isempty(sd.DopingElement))
                    obj.DopingElements(i) = sd.DopingElement;
                else
                    obj.DopingElements(i) = "";
                end
                obj.DIs(i) = sd.DI;
                obj.ASnos(i) = length(sd.ASCN);
            end
        end

        function obj = MLbuild(obj)
            [obj.MLmodel, obj.MAE_MLmodel] = GPRModel_Fcn(obj.FingerPrints, obj.dE_trains);
            obj.dE_tests = predict(obj.MLmodel.RegressionGP,obj.FingerPrints);
        end

        function obj2 = Prediction(obj,obj2)
            [obj2.dE_tests,~,dEint] = predict(obj.MLmodel.RegressionGP,obj2.FingerPrints,'Alpha',0.05);
            obj2.uncertaintys = abs(dEint(:,1)-dEint(:,2))/6;
            obj2.MAE_tests = mean(abs(obj2.dE_tests-obj2.dE_trains));
        end
        
        function ParityPlot(obj, TrainNC, TestNC, MAE_Train, MAE_Test)
            indexTrain = randsample(1:length(obj.dE_trains),round(0.8*length(obj.dE_trains)));
            indexTest = setdiff(1:length(obj.dE_trains),indexTrain);
            TrainNC.FingerPrints = obj.FingerPrints(indexTrain,:);
            TrainNC.dE_trains = obj.dE_trains(indexTrain,:);
            TestNC.FingerPrints = obj.FingerPrints(indexTest,:);
            TestNC.dE_trains = obj.dE_trains(indexTest,:);

            TrainNC = MLbuild(TrainNC); 
            TestNC = Prediction(TrainNC,TestNC,0,0);

            for i = 1:length(obj.DopingElements)
                if(isequal(obj.DopingElements(i),""))
                    obj.DopingElements(i) = "Pt";
                end 
            end

            figure;
            for i = 1:length(TrainNC.dE_trains)
                sd = SingleData;
                sd.DopingElement = obj.DopingElements(indexTrain(i));
                [~, ~, AtomColor] = readAtomProperties(sd, sd.DopingElement);
                hold on;
                scatter(TrainNC.dE_trains(i), TrainNC.dE_tests(i),100,'MarkerEdgeColor',AtomColor/255,'MarkerFaceColor',AtomColor/255,...
                        'MarkerEdgeAlpha',0.1, 'MarkerFaceAlpha',0.3);
            end
            for i = 1:length(TestNC.dE_trains)
                sd = SingleData;
                sd.DopingElement = obj.DopingElements(indexTest(i));
                [~, ~, AtomColor] = readAtomProperties(sd, sd.DopingElement);
                hold on;
                scatter(TestNC.dE_trains(i), TestNC.dE_tests(i),100,'d','MarkerEdgeColor',AtomColor/255);
            end
%             tempE = [TrainNC.dE_trains; TestNC.dE_trains];
            x = linspace(-3.5, -0.5, 11);  % linspace(min(tempE)-0.2, max(tempE)+0.2, 10);
            y = x;
            plot(x,y,'k','LineStyle','--');
            text(max(x)-1.0, min(y)+0.5,['MAE_{Test} = ' num2str(mean(MAE_Test),2) ' eV']);
            text(max(x)-1.0, min(y)+1, ['MAE_{Validation} = ' num2str(mean(MAE_Train),2) ' eV']);
            xlim([min(x) max(x)]);
            ylim([min(x) max(x)]);
            box on;
            xlabel('\Delta\itE\rm_{ads,DFT} (eV)');
            ylabel('\Delta\itE\rm_{ads,GPR} (eV)');

            unqIC = unique(obj.DopingElements);
            for i = 1:length(unqIC)
                sd = SingleData;
                [~, ~, tempcolor] = readAtomProperties(sd, unqIC(i));
                if(mod(i,2)== 1)
                    scatter(min(x)+0.3-0.15, max(y)-0.3-0.2*i/2,80,'filled','MarkerEdgeColor',tempcolor/255,'MarkerFaceColor',tempcolor/255,...
                        'MarkerEdgeAlpha',1.0, 'MarkerFaceAlpha',0.3);
                    hold on;
                    text(min(x)+0.45-0.15, max(y)-0.3-0.2*i/2,unqIC(i));
                else
                    scatter(min(x)+0.8-0.15, max(y)-0.3-0.2*(i-1)/2,80,'filled','MarkerEdgeColor',tempcolor/255,'MarkerFaceColor',tempcolor/255,...
                        'MarkerEdgeAlpha',1.0, 'MarkerFaceAlpha',0.3);
                    hold on;
                    text(min(x)+0.95-0.15, max(y)-0.3-0.2*(i-1)/2,unqIC(i));
                end
             end

        end



    end


end


