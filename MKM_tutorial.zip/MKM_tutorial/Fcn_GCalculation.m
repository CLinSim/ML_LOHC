function [dG,dGact]= Fcn_GCalculation(ddE_PtM, T)


    % format of ddE_PtM is [C7H13*; C7H12*; ...; C7H8*] collum vector!

    SvibC7H14gas_T = 0.0050746;  % Should be ideal gas!!! Fcn_SvibCalc(T,'C7H14');
    SvibC7H8gas_T = 0.0047033;  % Should be ideal gas!!! Fcn_SvibCalc(T,'C7H8');
    SvibH2gas_T = 0.00164;  % Should be ideal gas!!! Fcn_SvibCalc(T,'H2gas');
    SvibHPt_T = Fcn_SvibCalc(T,'HPt');
    Svibads_T = zeros(7,1);
    SvibTS_T = zeros(6,1);
    for i = 8:14
        Svibads_T(14+1-i) = Fcn_SvibCalc(T,['C7H' num2str(i) 'Pt']);
        if(i<14)
            SvibTS_T(14-i) = Fcn_SvibCalc(T,['TS' num2str(i) 'H']);
        end
    end

%     Svibads_T(1) = 0.70*SvibC7H14gas_T - 3.3*8.63*10^(-5);

    tempS = importdata('FreqFiles/PEandZPE.xlsx');

    Edata = tempS.data(:,1);
    ZPE = tempS.data(:,2);
    E_TS = tempS.data(2:7,3);
    ZPE_TS = tempS.data(2:7,4);

    dEact0 = E_TS - Edata(2:7);
    dEact_TS0 = ZPE_TS-T*SvibTS_T-(ZPE(2:7)-T*Svibads_T(1:end-1));

    dE0 = Edata(3:8) + Edata(10)-Edata(12)-Edata(2:7);
    dE_TS0 = (ZPE(3:8)-T*Svibads_T(2:end)) + (ZPE(10)-T*SvibHPt_T)...
        -(ZPE(2:7)-T*Svibads_T(1:end-1));

    dEact = dEact0;
    dE = dE0;
    p = polyfit(dE, dEact, 1);

    dGact0 = (E_TS+ZPE_TS-T*SvibTS_T)-(Edata(2:7)+ZPE(2:7)-T*Svibads_T(1:end-1));

    Edata(3:8) = Edata(3:8) + ddE_PtM; 
    dE_CHbreak = Edata(3:8) + Edata(10)-Edata(12)-Edata(2:7);
    dG_CHbreak = dE_CHbreak + dE_TS0;
    
    dGact = dEact0 + (dE_CHbreak-dE0)*p(1) + dEact_TS0;
    dGact(dGact<0.05) = 0.05;

    dGadsMCH = (Edata(2)+ZPE(2)-T*Svibads_T(1))-Edata(12)-(Edata(1)+ZPE(1)-T*SvibC7H14gas_T);
    dGadsTOL = (Edata(8)+ZPE(8)-T*Svibads_T(7))-Edata(12)-(Edata(9)+ZPE(9)-T*SvibC7H8gas_T);
    dGadsH2 = 2*(Edata(10)+ZPE(10)-T*SvibHPt_T)-2*Edata(12)-(Edata(11)+ZPE(11)-T*SvibH2gas_T);
    
    dG = [dG_CHbreak; dGadsH2; dGadsMCH; dGadsTOL];

    % % definition in dG: C7H14-C7H13, 13-12, 12-11, 11-10, 10-9, 9-8, H2
    % ads, MCH ads, TOL ads. 9 steps in total
end
