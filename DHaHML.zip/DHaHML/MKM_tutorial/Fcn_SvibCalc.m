
function SvibT = Fcn_SvibCalc(T,ChemicalName)

tempS = importdata(['FreqFiles/Freq_' ChemicalName '.log']);
for j = 3:length(tempS)
    si = j-2;
    S(si) = str2double(tempS{j});
    if(isreal(S(si)))
        if(S(si)<0.0015)
            S(si) = 0.0015;
        end
    else
        if(imag(S(si))<0.0124 && imag(S(si))>10^(-5))
            S(si) = 0.0015;
        else
            S(si) = real(S(si));
        end
    end
end
S = S(S>0);
kBT = T*8.617*10^(-5);

SvibT = 0;
for i = 1:length(S)
   wi = S(i)/kBT;
   SvibT = SvibT + kBT*(wi/(exp(wi)-1)-log(1-exp(-wi)))/T;
end


end

