function [kf,kb,Bsurf] = Fcn_Lumpkfkb(kforg,kborg,starads,Hads)

    kfapp_i = kforg(1)*kforg(2)*starads^2/(kborg(1)*Hads + kforg(2)*starads);
    kbapp_i = kborg(1)*kborg(2)*Hads^2/(kborg(1)*Hads + kforg(2)*starads);
    sc_13 = [kfapp_i/(kforg(2)*1); kbapp_i/(kborg(1)*1)];  % SC of 13 is sc_13(1)*SC14 + sc_13(2)*SC12;

    kfapp_ii = kforg(3)*kforg(4)*starads^2/(kborg(3)*Hads + kforg(4)*starads);
    kbapp_ii = kborg(3)*kborg(4)*Hads^2/(kborg(3)*Hads + kforg(4)*starads);
    sc_11 = [kfapp_ii/(kforg(4)*1); kbapp_ii/(kborg(3)*1)]; % SC of 11 is sc_11(1)*SC12 + sc_11(2)*SC10;

    kfapp_iii = kforg(5)*kforg(6)*starads^2/(kborg(5)*Hads + kforg(6)*starads);
    kbapp_iii = kborg(5)*kborg(6)*Hads^2/(kborg(5)*Hads + kforg(6)*starads);
    sc_9 = [kfapp_iii/(kforg(6)*1); kbapp_iii/(kborg(5)*1)]; % SC of 13 is sc_9(1)*SC10 + sc_9(2)*SC8;


    kfapp_iv = kfapp_ii*kfapp_iii/(kbapp_ii + kfapp_iii);
    kbapp_iv = kbapp_ii*kbapp_iii/(kbapp_ii + kfapp_iii);
    sc_10 = [kfapp_iv/kfapp_iii; kbapp_iv/kbapp_ii]; % SC of 10 is sc_10(1)*SC12 + sc_10(2)*SC8;

    kfapp_v = kfapp_i*kfapp_iv/(kbapp_i+kfapp_iv);
    kbapp_v = kbapp_i*kbapp_iv/(kbapp_i+kfapp_iv);
    sc_12 = [kfapp_v/kfapp_iv; kbapp_v/kbapp_i]; % SC of 12 is sc_12(1)*SC14 + sc_12(2)*SC8;
   
    kf(1) = kfapp_v;
    kb(1)= kbapp_v;
    
%     sc_13(1)*SC14 + sc_13(2)*sc_12(1)*SC14 + sc_13(2)*sc_12(2)*SC8 + sc_11(1)*sc_12(1)*SC14 + sc_11(1)*sc_12(2)*SC8 +...
%         sc_11(2)*sc_10(1)*sc_12(1)*SC14 + sc_11(2)*sc_10(1)*sc_12(2)*SC8 + sc_11(2)*sc_10(2)*SC8 + ...
%         sc_9(1)*sc_10(1)*sc_12(1)*SC14 + sc_9(1)*sc_10(1)*sc_12(2)*SC8 + sc_9(1)*sc_10(2)*SC8 + sc_9(2)*SC8 + ...
%         sc_10(1)*sc_12(1)*SC14 + sc_10(1)*sc_12(2)*SC8 + sc_10(2)*SC8 + sc_12(1)*SC14 + sc_12(2)*SC8;
  
    Bsurf = zeros(2,1);
    Bsurf(1) = 1 + sc_13(1) + sc_13(2)*sc_12(1) + sc_11(1)*sc_12(1) + sc_11(2)*sc_10(1)*sc_12(1) + sc_9(1)*sc_10(1)*sc_12(1) +...
                sc_10(1)*sc_12(1) + sc_12(1);
    Bsurf(2) = 1 + sc_13(2)*sc_12(2) + sc_11(1)*sc_12(2) + sc_11(2)*sc_10(1)*sc_12(2) + sc_11(2)*sc_10(2) +...
            sc_9(1)*sc_10(1)*sc_12(2) + sc_9(1)*sc_10(2) + sc_9(2) + sc_10(1)*sc_12(2) + sc_10(2) + sc_12(2);
end