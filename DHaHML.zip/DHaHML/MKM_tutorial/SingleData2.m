classdef SingleData

    properties
        dE_train;
        FingerPrint;
        DopingElement;
        BulkElement;

        ASCN;
        ASstr;
        NNCCN;
        NNCN;
        NNstr;
        dCM=[];
        DI;

        dE_test;
        uncertainty;

        File_atom = 'AtomProperties.xlsx';
        Egas = -1222.32;
        cutoff_CC = 1.6;
        cutoff_CH = 1.3;
        cutoff_NCNC = 3.2;
    end

    methods
        % this is to get Astr, AXYZ, dE, bulk and doping elements
        function [obj, Astr, Adata] = ReadXYZ(obj, filenameAds, filenameNC)
            delimiterIn = ' ';
            headerlinesIn = 2;
            Axyz = importdata(filenameAds,delimiterIn,headerlinesIn);
            Astr = Axyz.textdata{2};
            kAstr = strfind(Astr,'energy');
            Etot = str2double(Astr(kAstr+7:kAstr+20));
            Astr = Axyz.textdata(3:end);
            Adata = Axyz.data;

            if(~isempty(filenameNC))
                Axyz = importdata(filenameNC,delimiterIn,headerlinesIn);
                AstrNC = Axyz.textdata{2};
                kAstr = strfind(AstrNC,'energy');
                EtotNC = str2double(AstrNC(kAstr+7:kAstr+20));
                AstrNC = Axyz.textdata(3:end);
                obj.dE_train = Etot-EtotNC-obj.Egas;
                strEle = [];
                noEle = [];
                for i = 1:length(AstrNC)
                    logic_newstr = 1;
                    tempstr = string(AstrNC{i});
                    for j = 1:length(strEle)
                        if(isequal(tempstr,strEle(j)))
                            logic_newstr = 0;
                            noEle(j) = noEle(j)+1;
                            break;
                        end
                    end
                    if(logic_newstr)
                        strEle = [strEle tempstr];
                        noEle(length(noEle)+1) = 1;
                    end
                end
                [~,tempindex] = sort(noEle,'descend');
                bulkEle = strEle(tempindex(1));
                if(length(tempindex)>1.2)
                    dopingEle = strEle(tempindex(2));
                else
                    dopingEle = [];
                end
                obj.BulkElement = bulkEle;
                obj.DopingElement = dopingEle;
            end
        end

        function [obj,indexPt,index_allPtNN] = AS1NNinfo(obj, Astr, Adata)
            tempnoC = 1;
            tempnoH = 1;
            tempnoNC = 1;
            indexM2 = [];
            for i=1:length(Astr)
                switch Astr{i}
                    case obj.BulkElement
                        NC(tempnoNC,1:3) = Adata(i,1:3);
                        NCstr(tempnoNC) = string(Astr{i});
                        tempnoNC = tempnoNC + 1;
                    case 'C'
                        C(tempnoC,1:3) = Adata(i,1:3);
                        tempnoC = tempnoC + 1;
                    case 'H'
                        H(tempnoH, 1:3) = Adata(i,1:3);
                        tempnoH = tempnoH + 1;
                    otherwise
                        NC(tempnoNC,1:3) = Adata(i,1:3);
                        NCstr(tempnoNC) = string(Astr{i});
                        indexM2 = [indexM2 tempnoNC];
                        tempnoNC = tempnoNC +1;  
                end
            end
            noC = tempnoC -1;
            noH = tempnoH -1;
            noNC = tempnoNC -1;
            
            indexC = [];
            tempdCC = zeros(noC,noC);
            tempdCH = zeros(noC,noH);
            for i = 1:noC
                % closest C for each C
                for j = 1:noC
                    tempdCC(i,j) = sqrt(sum((C(i,:)-C(j,:)).^2));
                    if(tempdCC(i,j) > obj.cutoff_CC)
                        tempdCC(i,j)=0;
                    end
                end
                % closest H for each C
                for j = 1:noH
                    tempdCH(i,j) = sqrt(sum((C(i,:)-H(j,:)).^2));
                    if(tempdCH(i,j) > obj.cutoff_CH)
                        tempdCH(i,j)=0;
                    end
                end
                tempCC1 = tempdCC(i,:);
                tempCH1 = tempdCH(i,:);
                if(length(tempCC1(tempCC1>0))+length(tempCH1(tempCH1>0))<4)
                    indexC = [indexC i];
                end
            end

            tempdCNC = [];
            tempdC1NC = zeros(1,noNC);
            indexPt = [];
            for ci = 1:length(indexC)
                for j = 1:noNC
                    tempdC1NC(j) = sqrt(sum((C(indexC(ci),:)-NC(j,1:3)).^2));
                end
                [~,indexPtnew] = min(tempdC1NC);
                tempdCNC = [tempdCNC min(tempdC1NC)];
                indexPt = [indexPt indexPtnew]; 
            end
            tempindexPt = indexPt;
            indexPt = unique(indexPt);
            obj.dCM = mean(tempdCNC);
            obj.NNCCN = cell(length(indexPt),1);
            for i = 1:length(indexPt)
                obj.NNCCN{i} = find(tempindexPt == indexPt(i));
            end

            obj.ASCN = zeros(1,length(indexPt));
            obj.NNCN = cell(1,length(indexPt));
            obj.NNstr = cell(1,length(indexPt));

            tempdNCNC = zeros(noNC,noNC);
            indexPtNN = cell(noNC,1);
            nbPt = zeros(noNC,1);
            for i = 1:noNC
                for j = 1:noNC
                    tempdNCNC(i,j) = sqrt(sum((NC(i,1:3)-NC(j,1:3)).^2));
                    if(tempdNCNC(i,j)> obj.cutoff_NCNC)
                            tempdNCNC(i,j) = 0;
                    end
                end
                templist = tempdNCNC(i,:);
                indexPtNN{i} = find(templist>0); 
                nbPt(i) = length(templist(templist>0));
            end

            index_allPtNN = [];
            temp = cell(1);
            for i = 1:length(indexPt)
                temp{1}(i) = NCstr(indexPt(i));
                obj.ASCN(i) = nbPt(indexPt(i));
                obj.NNCN{i} = nbPt(indexPtNN{indexPt(i)});
                obj.NNstr{i} = NCstr(indexPtNN{indexPt(i)});
                index_allPtNN = [index_allPtNN indexPtNN{indexPt(i)}];
            end
            obj.ASstr = temp;
            index_allPtNN = setdiff(index_allPtNN,indexPt);
            index_allPtNN = unique(index_allPtNN);

            obj.DI = 0;
            for i = 1:length(indexPt)
                if(isequal(NCstr(indexPt(i)),obj.BulkElement))
                    continue
                else
                    obj.DI = obj.DI+1;
                end
            end
            for i = 1:length(index_allPtNN)
                if(isequal(NCstr(index_allPtNN(i)),obj.BulkElement))
                    continue
                else
                    obj.DI = obj.DI+0.5;
                end
            end
            
        end

        function [AtomEcoh, AtomX, AtomColor] = readAtomProperties(obj, AtomStr)
            AP = importdata(obj.File_atom);
            AtomColor = [];
            AtomEcoh = [];
            AtomX = [];
            for i = 1:length(AP.textdata)
                if(isequal(AtomStr,string(AP.textdata{i})))
                    AtomEcoh = AP.data(i,1);
                    AtomX = AP.data(i,3);
                    AtomColor = AP.data(i,4:6);
                    break
                end
            end
        end

        function obj = FingerPrinting(obj)
            gCN = 0*obj.ASCN;
            gCE = 0*obj.ASCN;
            [CEcoh, CX] = readAtomProperties(obj, "C");

            for i = 1:length(gCN)
%                 temp1NNCN = obj.NNCN{i};
                temp1NNstr = obj.NNstr{i};
                AtomEcoh = zeros(length(temp1NNstr),1);
                AtomX = zeros(length(temp1NNstr),1);
                tempNNCNN = obj.NNCCN{i};
                [ASEcoh, ASX] = readAtomProperties(obj, obj.ASstr{1}(i));
                for j = 1:length(temp1NNstr)
                    [AtomEcoh(j), AtomX(j)] = readAtomProperties(obj, temp1NNstr(i));
                end
                gCE(i) = sum(ASEcoh*AtomEcoh)/(length(tempNNCNN)+obj.ASCN(i));  % /BulkEcoh(1)
                gCN(i) = sum(ASX*AtomX)/(length(tempNNCNN)+obj.ASCN(i));   % /BulkX(1)
                gCE(i) = gCE(i) + length(tempNNCNN)*(ASEcoh*CEcoh)/(length(tempNNCNN)+obj.ASCN(i));  % /BulkEcoh(1)
                gCN(i) = gCN(i) + length(tempNNCNN)*(ASX*CX)/(length(tempNNCNN)+obj.ASCN(i));   % /BulkX(1)

%                 gCE(i) = ASEcoh + sum(AtomEcoh)/(length(tempNNCNN)+obj.ASCN(i));  % /BulkEcoh(1)
%                 gCN(i) = ASX + sum(AtomX)/(length(tempNNCNN)+obj.ASCN(i));   % /BulkX(1)
%                 gCE(i) = gCE(i) + length(tempNNCNN)*CEcoh/(length(tempNNCNN)+obj.ASCN(i));  % /BulkEcoh(1)
%                 gCN(i) = gCN(i) + length(tempNNCNN)*CX/(length(tempNNCNN)+obj.ASCN(i));   % /BulkX(1)
            end
 
            if(isempty(obj.dCM))
                obj.FingerPrint = [mean(gCE), mean(gCN), 0];
            else
                obj.FingerPrint = [mean(gCE), mean(gCN), obj.dCM];   
            end
        end

        function obj = Prediction(obj, MLmodel)
            if(obj.FingerPrint(3)==0)
                dtemp = linspace(2.05, 2.95, 46);
                tempFP = zeros(length(dtemp),3);
                for i = 1:length(dtemp)
                    tempFP(i,1:3) = [obj.FingerPrint(1), obj.FingerPrint(2), dtemp(i)];
                end
                [Etemp,~,dEint] = predict(MLmodel.RegressionGP,tempFP,'Alpha',0.05);
                tempuncertainty = abs(dEint(:,1)-dEint(:,2))/6;
                [obj.uncertainty, indexminUC] = min(tempuncertainty);
                obj.dE_test = Etemp(indexminUC);
            else
                [obj.dE_test,~,dEint] = predict(MLmodel.RegressionGP,obj.FingerPrint,'Alpha',0.05);
                obj.uncertainty = abs(dEint(1)-dEint(2))/6;
            end
        end

        function Visualization(obj, filename, judgeTextOn)
            delimiterIn = ' ';
            headerlinesIn = 2;
            Axyz = importdata(filename,delimiterIn,headerlinesIn);
            NCXYZ = Axyz.data;
            NCStr = Axyz.textdata(3:end);
    
            ic = 1;
            ih = 1;
            iPt = 1;
            iO = 1;
            molC = [];
            molH = [];
            molPt = [];
            molO = [];
            noPt = [];
            noO = [];
            istr = 1;
            for i = 1:size(NCXYZ,1)
                switch NCStr{i}
                    case 'C'
                        molC(ic,:) = NCXYZ(i,:);
                        ic = ic+1;
                    case 'H'
                        molH(ih,:) = NCXYZ(i,:);
                        ih = ih+1;
                    case 'Pt'
                        molPt(iPt,:) = NCXYZ(i,:);
                        iPt = iPt+1;
                        noPt = [noPt i];
                    otherwise
                         molO(iO,:) = NCXYZ(i,:);
                         tempstrM{istr} = NCStr{i};
                         istr = istr +1;
                        iO = iO+1;
                        noO = [noO i];
                end
            end
            figure;
            if(~isempty(molPt))
                plot3(molPt(:,1),molPt(:,2),molPt(:,3),'o','MarkerSize',40, 'MarkerFaceColor',[189,192,186]*1.16/255,...
                    'MarkerEdgeColor',[67,67,67]/255);   % previous MEC [67,67,67]/255
                hold on;
            end
            
            if(~isempty(molO))
                for i = 1:size(molO,1)
                    [~, ~, AtomColor] = readAtomProperties(obj, string(tempstrM{i}));
                    plot3(molO(i,1),molO(i,2),molO(i,3),'o','MarkerSize',40, 'MarkerFaceColor',AtomColor/255,...
                    'MarkerEdgeColor',[67,67,67]/255);
                    hold on;
                end
            end
            if(~isempty(molC) && (~isempty(molC)))
                plot3(molC(:,1), molC(:,2), molC(:,3),'o','MarkerSize',20, 'MarkerFaceColor',[191, 103, 102]/255,...
                    'MarkerEdgeColor',[67,67,67]/255);
                plot3(molH(:,1), molH(:,2), molH(:,3),'o','MarkerSize',12, 'MarkerFaceColor',[119, 150, 154]/255,...
                    'MarkerEdgeColor',[67,67,67]/255); 
            end 
            
            if(judgeTextOn==1)
                for i = 1:size(molPt,1)
                    text(molPt(i,1),molPt(i,2),molPt(i,3),num2str(noPt(i)));
                end
                for i = 1:size(molO,1)
                    text(molO(i,1),molO(i,2),molO(i,3),num2str(noO(i)));
                end
            end
            axis off

        end



    end

        
end