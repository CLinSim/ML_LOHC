clear 

load('TrainedC7HXMLModels.mat');
Egas0 = [-1301.905, -1286.85932, -1269.5948, -1254.0461, -1236.8172, -1222.32];

for k = 1:6
    sd0{k} = SingleData;
    sd0{k}.Egas = Egas0(k);
    [sd0{k}, Astr{k}, Adata{k}] = ReadXYZ(sd0{k}, ['RefXYZFiles/ref_C7H' num2str(14-k) '.xyz'], 'RefXYZFiles/ref_PtNC.xyz');
    [sd0{k}, indexAS{k}, index_allASNN{k}] = AS1NNinfo(sd0{k}, Astr{k}, Adata{k});
    tempASandNN = [indexAS{k} index_allASNN{k}];
    tempASandNN = unique(tempASandNN);
    index_ASandNN{k} = tempASandNN;
end

AP = importdata('AtomProperties.xlsx');
for i = 1:length(AP.textdata)
    AtomStr{i} = AP.textdata{i};
    AtomColor(i,1:3)= AP.data(i,3:5);
end

usedM = [4,7,10];
indexASTOL = indexAS{6};
indexNNTOL = index_allASNN{6};
ti = 1;
for i = 1:length(indexASTOL)
    for j = i:length(indexASTOL)
        for k = 1:3:length(indexNNTOL)
            index_Mdopedall{ti} = [indexASTOL(i:j) randsample(indexNNTOL,k)];
            ti = ti+1;
        end
    end
end

dEads_TOL = zeros(length(usedM),length(index_Mdopedall));
for ai = 1:length(usedM)
    for Mi = 1:length(index_Mdopedall)
        M = AtomStr{usedM(ai)};
        index_Mdoped = index_Mdopedall{Mi};
        ddE_PtM = zeros(6,1);
        for k = 1:6
            Astr_M = Astr{k};
            for i = 1:length(index_Mdoped)
                Astr_M{index_Mdoped(i)}=M;
            end
            sd_M{k} = SingleData;
            [sd_M{k}, indexAS_M{k}, index_allASNN_M{k}] = AS1NNinfo(sd_M{k}, Astr_M, Adata{k});
            sd_M{k}.dCM=[];
            sd_M{k} = FingerPrinting(sd_M{k});
            sd_M{k} = Prediction(sd_M{k}, C7HX{k}.MLmodel);
            ddE_PtM(k) = sd_M{k}.dE_test-sd0{k}.dE_train;  
        end
        
        Tsim = 600;
        PH2 = 0;
        PMCH = 10;
        PTOL = 0;
        vin =  10*10^(-6); 
        
        [dG,dGact]= Fcn_GCalculation(ddE_PtM, Tsim);
        dG(end) = dG(end) + 0.5;  % assume the ads-ads interaction causing a 0.5 eV increase in TOL adsE.
        [TOFsim(ai,Mi), SCfin{ai,Mi}, SCH(ai,Mi), kall{ai,Mi}] = RateSimulator_org(dG,dGact,Tsim,vin,PMCH,PTOL,PH2);
        [TOFsim2(ai,Mi), SCfin2{ai,Mi}, SCH2(ai,Mi), kall2{ai,Mi}] = RateSimulator_lump(dG,dGact,Tsim,vin,PMCH,PTOL,PH2);

        if(TOFsim(ai,Mi)<0)
            disp('Negative TOF:');
            disp(M);
            disp(index_Mdoped);
        end
        
        dEads_TOL(ai,Mi) = sd_M{k}.dE_test-sd0{k}.dE_train;
    end
end

