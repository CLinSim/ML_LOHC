function [TOF_sim, SCfin, SCH, kall] = RateSimulator_lump(dG,dGa,T,vin,PMCH,PTOL,PH2)

PMCH0 = PMCH/10*10^5;
PTOL0 = PTOL/10*10^5;
PH20 = PH2/10*10^5;

kB = 1.38064*10^(-23);
RT = 8.3145*T/96485;
h = 6.62607015*10^(-34);
area_AS = 1*10^(-19);  %m^2
atomMass = 1.6605*10^(-24);

vout = vin;
NA = 6.02*10^23;
V = 1*10^(-6);         % m^3
V_cat = 0.1*10^(-6);      % m^3
area_cat = 0.2*10^6;          % m^2/kg
density_cat = 0.15*10^3;        % kg/m^3
porosity = 0.6;
% PMCH0 = 10^5;
MassRI = zeros(1,7); 
MassRI(1) = 98;
MassRI(end) = 92;

density_AS = area_cat*density_cat*(1-porosity)/(NA*area_AS);    %mol/m^3
mol_AS = density_AS*V_cat;      %mol;
nini = PMCH0*V/RT;
niniTOL = PTOL0*V/RT;
nH2 = PH20*V/RT;
RTV = RT/V;

tend = 4000.0;
dt0 = 1*10^(-3);
wt = 1.001;
dt = dt0;
tlist = zeros(1);
while(tlist(end)<tend)
    tlist = [tlist tlist(end)+dt]; 
    dt = dt*wt;
end
tlist(end) = tend;
nT = length(tlist);
y0 = zeros(4,nT); 
y0(3,1) = nini;
y0(4,1) = niniTOL;

cvsRecord = 0*tlist;

kads = zeros(2,1);
kdes = zeros(2,1);
kforg = zeros(6,1);
kborg = zeros(6,1);
for i = 1:6
    kforg(i) = kB*T/h*exp(-dGa(i)/RT);
    kborg(i) = kB*T/h*exp(-(dGa(i)-dG(i))/RT);
end
 kads(1) = area_AS/sqrt(2*pi*MassRI(1)*atomMass*kB*T);
 kdes(1) = kads(1)*100000/exp(-dG(8)/RT);
 kads(2) = area_AS/sqrt(2*pi*MassRI(7)*atomMass*kB*T);
 kdes(2) = kads(2)*100000/exp(-dG(9)/RT);

indexads = [1,2];
for k = 2:nT

    dT = tlist(k)-tlist(k-1);
    yold = y0(:,k-1);
    ytemp = y0(:,k-1);

    cvsRate = 0.0;
    cvsRate_fit = 0.005;

    error = 1;

    while(error>abs(cvsRate_fit)/5000)
        cvsRate = (cvsRate + cvsRate_fit)/2;
        cvsRate_H2 = 3*cvsRate*nini+nH2;

        KeqH2 = exp(-dG(7)/RT)*cvsRate_H2*RTV/100000;
        Hads = sqrt(KeqH2)/(1+sqrt(KeqH2));
        starads = 1-Hads;
        [kf,kb,Bsurf] = Fcn_Lumpkfkb(kforg,kborg,starads,Hads);

        CoeffMatrix_itoj = zeros(4,4);
        bCoeff = zeros(4,1);

        bCoeff(1) = yold(1)/dT + kads(1)*yold(3)*RTV;
        CoeffMatrix_itoj(1,1) = 1/dT + kdes(1) + kf + kads(1)*yold(3)*RTV*Bsurf(1);
        CoeffMatrix_itoj(1,2) = -kb + kads(1)*yold(3)*RTV*Bsurf(2);

        bCoeff(2) = yold(2)/dT + kads(2)*yold(4)*RTV;
        CoeffMatrix_itoj(2,2) = 1/dT + kdes(2) + kb + kads(2)*yold(4)*RTV*Bsurf(2);
        CoeffMatrix_itoj(2,1) = -kf + kads(2)*yold(4)*RTV*Bsurf(1);

        bCoeff(3) = yold(3)/dT + nini*vin/V - mol_AS*kads(1)*yold(3)*RTV;
        CoeffMatrix_itoj(3,1) = -mol_AS*kdes(1) -mol_AS*kads(1)*yold(3)*RTV*Bsurf(1);
        CoeffMatrix_itoj(3,2) = -mol_AS*kads(1)*yold(3)*RTV*Bsurf(2);
        CoeffMatrix_itoj(3,3) = 1/dT + vout/V;

        bCoeff(4) = yold(4)/dT + niniTOL*vin/V - mol_AS*kads(2)*yold(4)*RTV;
        CoeffMatrix_itoj(4,1) = -mol_AS*kads(2)*yold(4)*RTV*Bsurf(1);
        CoeffMatrix_itoj(4,2) = -mol_AS*kdes(2)-mol_AS*kads(2)*yold(4)*RTV*Bsurf(2);
        CoeffMatrix_itoj(4,4) = 1/dT + vout/V;

        ytemp = CoeffMatrix_itoj\bCoeff;
        y0(:,k) = ytemp;

        cvsRate_fit = (y0(end,k)-niniTOL)/nini;

        error = abs(cvsRate_fit-cvsRate)/2;

    end
    cvsRecord(k) = cvsRate_fit;
end

TOF_sim = kads(1)*RTV*y0(3,end-1)*(1-sum(Bsurf.*y0(indexads,end)))-kdes(1)*y0(1,end);
SCfin = y0(:,end);

SCH = Hads;

kall = zeros(3,2);
kall(1,1) = kf;
kall(1,2) = kb;
kall(2,1) = kads(1);
kall(2,2) = kdes(1);
kall(3,1) = kads(2);
kall(3,2) = kdes(2);

end