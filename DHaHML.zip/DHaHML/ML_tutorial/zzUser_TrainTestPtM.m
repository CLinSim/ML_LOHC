
clear

load('Features\Data_RandomPt.mat');

nTrain = 5;
[mean_MAE_train, mean_MAE_test, TrainNC, TestNC] = RepeatTest(nTrain,RandomPt);

MAE3 = zeros(3,1);
for i = 1:length(MAE3)
    NewPt = RandomPt;
    indexRand = randsample(1:length(RandomPt.dE_trains), length(RandomPt.dE_trains));
    NewPt.FingerPrints(:,i) = RandomPt.FingerPrints(indexRand,i);
    [~, temp_MAE_test] = RepeatTest(nTrain,NewPt);
    MAE3(i) = temp_MAE_test(end);
end

dMAE3 = (MAE3-mean_MAE_test(end))/mean_MAE_test(end)*100;
figure;
X = categorical(["F1","F2","F3"]);
X = reordercats(X,["F1","F2","F3"]);
bar(X,dMAE3');
ylabel('\DeltaMAE/MAE_{test} (%)');

figure;
plot(mean_MAE_train,'Marker','square'); 
hold on;
plot(mean_MAE_test,'Marker','square');
xlabel('Iteration');
ylabel('MAE (eV)');
ylim([0.1 0.2]);

ParityPlot(RandomPt, TrainNC, TestNC, mean_MAE_train(end), mean_MAE_test(end));

function [mean_MAE_train, mean_MAE_test, TrainNC, TestNC] = RepeatTest(nTrain,RandomPt)
    % nTrain = 50;
    MAE_train = zeros(nTrain,1);
    MAE_test = zeros(nTrain,1);
    
    for i = 1:nTrain
        indexTrain = randsample(1:length(RandomPt.dE_trains),round(0.8*length(RandomPt.dE_trains)));
        indexTest = setdiff(1:length(RandomPt.dE_trains),indexTrain);
        TrainNC = EnsembleData;
        TestNC = EnsembleData;
        TrainNC.FingerPrints = RandomPt.FingerPrints(indexTrain,:);
        TrainNC.dE_trains = RandomPt.dE_trains(indexTrain,:);
        TestNC.FingerPrints = RandomPt.FingerPrints(indexTest,:);
        TestNC.dE_trains = RandomPt.dE_trains(indexTest,:);
    
        TrainNC = MLbuild(TrainNC);
        MAE_train(i) = TrainNC.MAE_MLmodel;
    
        TestNC = Prediction(TrainNC,TestNC,0,0);
        MAE_test(i) = TestNC.MAE_tests;
    end
    
    mean_MAE_train = 0*MAE_train;
    mean_MAE_test = 0*MAE_test;
    for i = 1:nTrain
        mean_MAE_train(i) = mean(MAE_train(1:i));
        mean_MAE_test(i) = mean(MAE_test(1:i));
    end
end




