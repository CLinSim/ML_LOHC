% % This script is to extract features from training data

%% 
% RandomPt = EnsembleData;
% RandomPt = FolderAnalysis(RandomPt, 'Data_DFT\RandomDopedPt55',[]);
% RandomPt = MLbuild(RandomPt);
% 
% save('Features\Data_RandomPt.mat','RandomPt');
% 
% RandomPtnew = RandomPt;
% figure;
% for i = 1:3
%     subplot(2,2,i);
%     histfit(RandomPtnew.FingerPrints(:,i));
% end
% subplot(2,2,4);
% histfit(RandomPtnew.dE_trains);

%%
% CuM = EnsembleData;
% CuM = FolderAnalysis(CuM, 'CuNCs',[]);
% save('Data_CuNC.mat','CuM'); 


% CSNC= EnsembleData;
% CSNC = FolderAnalysis(CSNC, 'CoreShell',[]);
% save('Data_CoreShell.mat','CSNC');


% MTest= EnsembleData;
% MTest = FolderAnalysis(MTest, 'MTest',[]);
% save('Data_MTest.mat','MTest');

%%
% C7H13= EnsembleData;
% C7H13 = FolderAnalysis(C7H13, 'C7H13ads', -1301.905);
% save('Data_C7H13.mat','C7H13');
% 
% C7H10= EnsembleData;
% C7H10 = FolderAnalysis(C7H10, 'C7H10ads', -1254.0461);
% save('Data_C7H10.mat','C7H10');
% 
% C7H12= EnsembleData;
% C7H12 = FolderAnalysis(C7H12, 'C7H12ads', -1287.093);
% save('Data_C7H12.mat','C7H12');
% 
% C7H11= EnsembleData;
% C7H11 = FolderAnalysis(C7H11, 'C7H11ads', -1269.5948);
% save('Data_C7H11.mat','C7H11');
% 
% C7H9= EnsembleData;
% C7H9 = FolderAnalysis(C7H9, 'C7H9ads', -1236.8172);
% save('Data_C7H9.mat','C7H9');
% 



