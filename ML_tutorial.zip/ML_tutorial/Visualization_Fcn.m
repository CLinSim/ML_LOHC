function Visualization_Fcn(filename)
CE = importdata('AtomProperties.xlsx');
tempSTM = [];
for i = 1:length(CE.textdata)
    tempSTM = [tempSTM string(CE.textdata{i})];
end
colorTM = CE.data(:,3:5)/255;


delimiterIn = ' ';
headerlinesIn = 2;
Axyz = importdata(filename,delimiterIn,headerlinesIn);
NCXYZ = Axyz.data;
NCStr = Axyz.textdata(3:end);

        ic = 1;
        ih = 1;
        iPt = 1;
        iO = 1;
        molC = [];
        molH = [];
        molPt = [];
        molO = [];
        noPt = [];
        noO = [];
        istr = 1;
        for i = 1:size(NCXYZ,1)
            switch NCStr{i}
                case 'C'
                    molC(ic,:) = NCXYZ(i,:);
                    ic = ic+1;
                case 'H'
                    molH(ih,:) = NCXYZ(i,:);
                    ih = ih+1;
                case 'Pt'
                    molPt(iPt,:) = NCXYZ(i,:);
                    iPt = iPt+1;
                    noPt = [noPt i];
                otherwise
                     molO(iO,:) = NCXYZ(i,:);
                     tempstrM{istr} = NCStr{i};
                     istr = istr +1;
                    iO = iO+1;
                    noO = [noO i];
            end
        end
        
        figure;
        newmolPt = molPt;
        if(~isempty(newmolPt))
            plot3(newmolPt(:,1),newmolPt(:,2),newmolPt(:,3),'o','MarkerSize',40, 'MarkerFaceColor',[189,192,186]*1.16/255,...
                'MarkerEdgeColor',[67,67,67]/255);   % previous MEC [67,67,67]/255
            hold on;
        end
        
        if(~isempty(molO))
            for i = 1:size(molO,1)
                tempindex = find(tempSTM == string(tempstrM{i}));
                tempcolor = colorTM(tempindex,:);
                plot3(molO(i,1),molO(i,2),molO(i,3),'o','MarkerSize',40, 'MarkerFaceColor',tempcolor,...
                'MarkerEdgeColor',[67,67,67]/255);
                hold on;
            end
        end

        if(~isempty(molC))
            plot3(molC(:,1), molC(:,2), molC(:,3),'o','MarkerSize',20, 'MarkerFaceColor',[191, 103, 102]/255,...
                'MarkerEdgeColor',[67,67,67]/255);
            hold on;
        end

        if(~isempty(molH))
            plot3(molH(:,1), molH(:,2), molH(:,3),'o','MarkerSize',12, 'MarkerFaceColor',[119, 150, 154]/255,...
                'MarkerEdgeColor',[67,67,67]/255); 
        end 

        axis off
end