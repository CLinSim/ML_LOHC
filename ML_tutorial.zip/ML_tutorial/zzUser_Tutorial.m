 
% % This is to read and analyse one .xyz file

sd = SingleData; 
fileName_adsNC = 'Data_DFT\RandomDopedPt55\5_TOL.xyz';
fileName_NC = 'Data_DFT\RandomDopedPt55\5_Mo8.xyz';
[sd, Astr, Adata] = ReadXYZ(sd, fileName_adsNC, fileName_NC);
sd = AS1NNinfo(sd, Astr, Adata);
sd = FingerPrinting(sd);

%%
% % This is to train a GPR model in order to predict the adsorption
% % energy of sd

load('Features\RandomDopedPt55.mat');

indexTrain = randsample(1:length(RandomPt.dE_trains),round(0.8*length(RandomPt.dE_trains)));

indexTest = setdiff(1:length(RandomPt.dE_trains),indexTrain);

TrainNC = EnsembleData;
TestNC = EnsembleData;
TrainNC.FingerPrints = RandomPt.FingerPrints(indexTrain,:);
TrainNC.dE_trains = RandomPt.dE_trains(indexTrain,:);
TestNC.FingerPrints = RandomPt.FingerPrints(indexTest,:);
TestNC.dE_trains = RandomPt.dE_trains(indexTest,:);

TrainNC = MLbuild(TrainNC);
MAE_train = TrainNC.MAE_MLmodel;

TestNC = Prediction(TrainNC,TestNC);
MAE_test = TestNC.MAE_tests;

ParityPlot(RandomPt, TrainNC, TestNC, MAE_train, MAE_test);

%% 
% % This is to predict the adsorption energy of the structure saved in sd


sd = Prediction(sd, RandomPt.MLmodel);

sd2 = sd;
sd2.FingerPrint(3) = 0;
sd2 = Prediction(sd2, RandomPt.MLmodel);


